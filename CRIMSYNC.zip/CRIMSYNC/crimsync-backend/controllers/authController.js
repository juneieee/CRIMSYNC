const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Signup (unchanged)
exports.signup = async (req, res) => {
  try {
    const { email, password, role, name, phone } = req.body;
    
    if (await User.findOne({ email })) {
      return res.status(400).json({ error: 'Email already in use' });
    }

    const user = await User.create({ 
      email, 
      password: await bcrypt.hash(password, 12), 
      role,
      name,
      phone
    });

    const token = jwt.sign(
      { userId: user._id }, 
      process.env.JWT_SECRET, 
      { expiresIn: '1d' }
    );

    res.status(201).json({ 
      user: {
        _id: user._id,
        email: user.email,
        role: user.role,
        name: user.name
      },
      token 
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Login (unchanged)
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { userId: user._id }, 
      process.env.JWT_SECRET, 
      { expiresIn: '1d' }
    );

    res.status(200).json({ 
      user: {
        _id: user._id,
        email: user.email,
        role: user.role,
        name: user.name
      },
      token 
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get My Profile (unchanged)
exports.getMe = async (req, res) => {
  try {
    const user = await User.findById(req.userId).select('-password');
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// NEW: Update Profile
exports.updateProfile = async (req, res) => {
  try {
    const { name, phone } = req.body;
    const user = await User.findByIdAndUpdate(
      req.userId,
      { name, phone },
      { new: true } // Returns updated document
    ).select('-password');
    
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};