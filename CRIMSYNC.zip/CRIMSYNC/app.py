from flask import Flask, render_template, redirect, url_for, session, g
import os
from datetime import timedelta
import secrets

# Initialize Flask app
app = Flask(__name__)

# ========================
# CONFIGURATION
# ========================
app.config.update({
    'SECRET_KEY': secrets.token_hex(32),  # Secure random key
    'PERMANENT_SESSION_LIFETIME': timedelta(minutes=30),
    'TEMPLATES_AUTO_RELOAD': True,
    'ANIMATION_DURATION': 7000  # 7 seconds in milliseconds
})

# ========================
# ROUTES
# ========================
@app.route('/')
def splash():
    """Show 7-second animated intro"""
    # Check if user previously skipped animation
    if session.get('skip_intro', False):
        return redirect(url_for('dashboard'))
    return render_template('splash.html')

@app.route('/dashboard')
def dashboard():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/skip-intro')
def skip_intro():
    """Allow users to skip the animation"""
    session['skip_intro'] = True
    return redirect(url_for('dashboard'))

# ========================
# ERROR HANDLERS
# ========================
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(e):
    return render_template('500.html'), 500

# ========================
# LAUNCH APPLICATION
# ========================
if __name__ == '__main__':
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        threaded=True
    )