from flask import Flask, render_template, redirect, url_for, session, g, request
from flask_mail import Mail, Message
import os
from datetime import timedelta
import secrets
from dotenv import load_dotenv

# Initialize Flask app
app = Flask(__name__)

# ========================
# CONFIGURATION (NEW MAIL SETTINGS ADDED)
# ========================
app.config.update({
    'SECRET_KEY': secrets.token_hex(32),
    'PERMANENT_SESSION_LIFETIME': timedelta(minutes=30),
    'TEMPLATES_AUTO_RELOAD': True,
    'ANIMATION_DURATION': 7000,
    # NEW: Email Configuration
    'MAIL_SERVER': 'smtp.gmail.com',
    'MAIL_PORT': 587,
    'MAIL_USE_TLS': True,
    'MAIL_USERNAME': os.getenv('EMAIL_USER'),
    'MAIL_PASSWORD': os.getenv('EMAIL_PASSWORD')
})

# NEW: Initialize Flask-Mail
mail = Mail(app)
load_dotenv()

# ========================
# EXISTING ROUTES (UNCHANGED)
# ========================
@app.route('/')
def splash():
    if session.get('skip_intro', False):
        return redirect(url_for('dashboard'))
    return render_template('splash.html')

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

@app.route('/skip-intro')
def skip_intro():
    session['skip_intro'] = True
    return redirect(url_for('dashboard'))

# ========================
# NEW CRIMSYNC ROUTES (WITH 2 CRITICAL FIXES)
# ========================
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # FIX 1: Add session variable to remember login
        session['logged_in'] = True
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        email = request.form.get('email')
        # FIX 2: Store password temporarily (for demo)
        session['temp_email'] = email
        session['temp_password'] = request.form.get('password')  # NEW LINE
        session['temp_otp'] = "123456"  # Demo OTP
        
        # NEW: Uncomment to enable real emails
        # msg = Message('Verify Your CrimSync Account',
        #              sender=app.config['MAIL_USERNAME'],
        #              recipients=[email])
        # msg.body = f'Your OTP: {session["temp_otp"]}'
        # mail.send(msg)
        
        return redirect(url_for('verify_email'))
    return render_template('signup.html')

@app.route('/verify-email', methods=['GET', 'POST'])
def verify_email():
    if request.method == 'POST':
        if request.form.get('otp') == session.get('temp_otp'):
            session['logged_in'] = True  # Auto-login after verification
            return redirect(url_for('dashboard'))
        return "Invalid OTP", 400
    return render_template('verify-email.html')

@app.route('/help-request')
def help_request():
    # NEW: Protect route if not logged in
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('help-request.html')

@app.route('/chat')
def chat():
    # NEW: Protect route if not logged in
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    return render_template('chat.html')

# ========================
# EXISTING ERROR HANDLERS (UNCHANGED)
# ========================
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(e):
    return render_template('500.html'), 500

# ========================
# LAUNCH APPLICATION (UNCHANGED)
# ========================
if __name__ == '__main__':
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        threaded=True
    )